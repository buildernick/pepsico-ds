# React + TypeScript + Vite

1. Do npm i
2. Copy content of src/externalLibraries to node_modules.
3. npm run dev

Figma: https://www.figma.com/design/CW7i2jUYPDtCQrhumsD9zd/Example-page---PepsiCo--NN-?node-id=52253-165455&t=cPwlbZTKiCJijZRq-0
